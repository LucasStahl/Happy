declare module "*.png"
